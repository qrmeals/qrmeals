<div class="col-lg-12 card">
    <h6><b>Admin  info</b></h6>
    <h6>Current Time Zone: {{ config('app.timezone')}} </h6>
    <h6>Current Currency: {{ config('settings.cashier_currency') }}</h6>
</div>